package com.gudhaking.social

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var verificationId: String? = null
    private var pickedImage: android.net.Uri? = null

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pickedImage = uri
        status.text = if (uri != null) "फोटो चुनी गई। अब पोस्ट शेयर करें।" else "कोई फोटो नहीं चुनी गई।"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 20)
            setBackgroundColor(Color.rgb(248, 248, 252))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val heading = TextView(this).apply {
            text = title
            textSize = 27f
            setTextColor(Color.rgb(111, 54, 190))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 22)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(heading)
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(4, 12, 4, 12)
        }
    }

    private fun field(hint: String, isPassword: Boolean = false): EditText {
        return EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setSingleLine(true)
            setPadding(16, 10, 16, 10)
            if (isPassword) inputType = 129
            root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(135, 75, 205))
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
    }

    private fun showHome() {
        base("gudha_king")
        val user = auth.currentUser
        if (user == null) {
            root.addView(TextView(this).apply {
                text = "अपना अकाउंट बनाएँ या लॉगिन करें"
                textSize = 16f
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
            })
            button("ईमेल से Login / Signup") { showEmailAuth() }
            button("मोबाइल OTP से Login") { showPhoneAuth() }
            root.addView(status)
        } else {
            root.addView(TextView(this).apply {
                text = "स्वागत है!\n${user.email ?: user.phoneNumber ?: "gudha_king user"}"
                textSize = 17f
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                setPadding(0, 8, 0, 18)
            })
            val caption = field("अपनी पोस्ट का कैप्शन लिखें")
            button("फोटो चुनें") { imagePicker.launch("image/*") }
            button("पोस्ट शेयर करें") { publishPost(caption.text.toString()) }
            button("Feed रीफ्रेश करें") { loadFeed() }
            button("Logout") { auth.signOut(); showHome() }
            root.addView(status)
            loadFeed()
        }
    }

    private fun showEmailAuth() {
        base("ईमेल Login / Signup")
        val email = field("ईमेल पता")
        val password = field("पासवर्ड (कम से कम 6 अक्षर)", true)
        button("नया अकाउंट बनाएँ") {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            if (e.isBlank() || p.length < 6) { status.text = "सही ईमेल और कम से कम 6 अक्षर का पासवर्ड डालें।"; return@button }
            auth.createUserWithEmailAndPassword(e, p)
                .addOnSuccessListener { saveProfile(); showHome() }
                .addOnFailureListener { status.text = it.localizedMessage ?: "Signup असफल हुआ।" }
        }
        button("पहले से अकाउंट है? Login करें") {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            auth.signInWithEmailAndPassword(e, p)
                .addOnSuccessListener { saveProfile(); showHome() }
                .addOnFailureListener { status.text = it.localizedMessage ?: "Login असफल हुआ।" }
        }
        button("वापस") { showHome() }
        root.addView(status)
    }

    private fun showPhoneAuth() {
        base("मोबाइल OTP Login")
        val phone = field("मोबाइल नंबर, जैसे +91XXXXXXXXXX")
        val otp = field("SMS में आया OTP")
        button("OTP भेजें") {
            val number = phone.text.toString().trim()
            if (!number.startsWith("+") || number.length < 10) {
                status.text = "देश कोड सहित नंबर डालें, जैसे +91XXXXXXXXXX"; return@button
            }
            val options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(number)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                        signInPhone(credential)
                    }
                    override fun onVerificationFailed(e: Exception) {
                        status.text = e.localizedMessage ?: "OTP भेजना असफल हुआ।"
                    }
                    override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                        verificationId = id
                        status.text = "OTP भेज दिया गया। अपना SMS देखें।"
                    }
                }).build()
            PhoneAuthProvider.verifyPhoneNumber(options)
        }
        button("OTP Verify करें") {
            val id = verificationId
            val code = otp.text.toString().trim()
            if (id.isNullOrBlank() || code.length < 4) {
                status.text = "पहले OTP मँगाएँ और सही कोड डालें।"; return@button
            }
            signInPhone(PhoneAuthProvider.getCredential(id, code))
        }
        button("वापस") { showHome() }
        root.addView(status)
    }

    private fun signInPhone(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener { saveProfile(); showHome() }
            .addOnFailureListener { status.text = it.localizedMessage ?: "OTP Login असफल हुआ।" }
    }

    private fun saveProfile() {
        val user = auth.currentUser ?: return
        val data = hashMapOf<String, Any>(
            "uid" to user.uid,
            "email" to (user.email ?: ""),
            "phone" to (user.phoneNumber ?: ""),
            "username" to "user_${user.uid.take(6)}",
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("users").document(user.uid).set(data)
    }

    private fun publishPost(caption: String) {
        val user = auth.currentUser ?: return
        val image = pickedImage
        if (caption.isBlank() && image == null) {
            status.text = "कैप्शन लिखें या फोटो चुनें।"; return
        }
        status.text = "पोस्ट अपलोड हो रही है..."
        if (image == null) {
            savePost(user.uid, caption, null)
        } else {
            val ref = storage.reference.child("post_images/${user.uid}/${System.currentTimeMillis()}.jpg")
            ref.putFile(image)
                .continueWithTask { task ->
                    if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                    ref.downloadUrl
                }
                .addOnSuccessListener { uri -> savePost(user.uid, caption, uri.toString()) }
                .addOnFailureListener { status.text = "अपलोड असफल: ${it.localizedMessage}" }
        }
    }

    private fun savePost(uid: String, caption: String, imageUrl: String?) {
        val data = hashMapOf<String, Any?>(
            "uid" to uid,
            "caption" to caption,
            "imageUrl" to imageUrl,
            "likesCount" to 0,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("posts").add(data)
            .addOnSuccessListener {
                pickedImage = null
                status.text = "पोस्ट ऑनलाइन शेयर हो गई!"
                loadFeed()
            }
            .addOnFailureListener { status.text = "पोस्ट सेव नहीं हुई: ${it.localizedMessage}" }
    }

    private fun loadFeed() {
        db.collection("posts").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(30).get()
            .addOnSuccessListener { result ->
                val label = TextView(this).apply {
                    text = "\n\n— नवीनतम पोस्ट —"
                    textSize = 18f
                    setTextColor(Color.rgb(65, 55, 85))
                }
                root.addView(label)
                for (doc in result.documents) {
                    val card = TextView(this).apply {
                        val cap = doc.getString("caption") ?: "(बिना कैप्शन)"
                        val uid = doc.getString("uid") ?: "user"
                        text = "\n@${uid.take(8)}\n$cap\n♡ ${doc.getLong("likesCount") ?: 0}\n"
                        textSize = 16f
                        setTextColor(Color.DKGRAY)
                        setPadding(12, 16, 12, 16)
                        setBackgroundColor(Color.WHITE)
                    }
                    root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
                }
                if (result.isEmpty) {
                    root.addView(TextView(this).apply {
                        text = "अभी कोई पोस्ट नहीं है। सबसे पहली पोस्ट आप करें!"
                        setTextColor(Color.GRAY)
                    })
                }
            }
            .addOnFailureListener { status.text = "Feed लोड नहीं हुई: ${it.localizedMessage}" }
    }
}
